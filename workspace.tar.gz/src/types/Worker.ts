export type WorkerJobFunction = (worker: Worker) => void;
