addEventListener("message", (e) => {
  console.log("Hello From example worker");
});
