export const phoneReg: RegExp = /(\+98|0098|98|0)?9\d{9}/gi;
