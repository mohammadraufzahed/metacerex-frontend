import { atom } from "recoil";

export const showSidebar = atom({
  key: "showSidebar",
  default: true,
});
